This application shows an approach how to solve the problem with ambiguities when translating a text. So get the right translation for a word, the actual sentence and the sentences around are searched for the occurence of other keywords to determine the topic of the sentence. If no resolution is found the word with the greatest likelyhood is chosen.

Author:
Andreas Schröder
Darmstadt